package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class EtatPassagerTest {

    // --- Tests positifs simples ---

    @Test
    public void estExterieurQuandEtatDehors() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEHORS);
        assertTrue(etat.estExterieur());
    }

    @Test
    public void estAssisQuandEtatAssis() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.ASSIS);
        assertTrue(etat.estAssis());
    }

    @Test
    public void estDeboutQuandEtatDebout() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEBOUT);
        assertTrue(etat.estDebout());
    }

    @Test
    public void estInterieurQuandEtatAssis() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.ASSIS);
        assertTrue(etat.estInterieur());
    }

    @Test
    public void estInterieurQuandEtatDebout() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEBOUT);
        assertTrue(etat.estInterieur());
    }

    // --- Tests négatifs (optionnels mais bien pour la note) ---

    @Test
    public void pasAssisQuandEtatDehors() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEHORS);
        assertFalse(etat.estAssis());
    }

    @Test
    public void pasDeboutQuandEtatDehors() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEHORS);
        assertFalse(etat.estDebout());
    }

    @Test
    public void pasInterieurQuandEtatDehors() {
        EtatPassager etat = new EtatPassager(EtatPassager.Etat.DEHORS);
        assertFalse(etat.estInterieur());
    }
}

