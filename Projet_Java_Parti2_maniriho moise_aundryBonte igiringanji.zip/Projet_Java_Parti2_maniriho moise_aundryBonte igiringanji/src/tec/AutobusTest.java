package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class AutobusTest {

    @Test
    public void busVideAuDepart() {
        Autobus bus = new Autobus(1, 2);
        assertEquals("[arret:0, assis:0, debout:0]", bus.toString());
    }

    @Test
    public void demanderPlaceAssiseMetPassagerAssis() {
        Autobus bus = new Autobus(1, 0);
        PassagerStandard p = new PassagerStandard("Kaylee", 5);
        bus.demanderPlaceAssise(p);
        assertTrue(p.estAssis());
    }

    @Test
    public void demanderPlaceDeboutMetPassagerDebout() {
        Autobus bus = new Autobus(0, 1);
        PassagerStandard p = new PassagerStandard("Jayne", 4);
        bus.demanderPlaceDebout(p);
        assertTrue(p.estDebout());
    }

    @Test
    public void allerArretSuivantIncrementeNumeroArret() throws UsagerInvalideException {
        Autobus bus = new Autobus(1, 1);
        bus.allerArretSuivant();
        // On vérifie via toString que l'arrêt est passé à 1
        assertTrue(bus.toString().startsWith("[arret:1"));
    }
}

