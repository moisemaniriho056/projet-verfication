package tec;

/**
 * Faux passager utilisé pour tester Autobus.
 * Il implémente Passager et Usager mais avec un comportement très simple :
 * on enregistre juste les appels dans l'attribut message.
 */
public class FauxPassager implements Passager, Usager {

  static final byte DEHORS = 0;
  static final byte ASSIS  = 1;
  static final byte DEBOUT = 2;

  byte status = DEHORS;
  String message = "???";

  // -------- Usager --------

  @Override
  public String nom() {
    return "Faux"; // on s'en fiche du vrai nom
  }

  @Override
  public void monterDans(Transport t) throws UsagerInvalideException {
    // On ne fait rien : ce faux passager sert surtout
    // pour vérifier les appels faits par le bus (demanderPlaceXXX).
  }

  // -------- Passager : état --------

  @Override
  public boolean estDehors() {
    return status == DEHORS;
  }

  @Override
  public boolean estAssis() {
    return status == ASSIS;
  }

  @Override
  public boolean estDebout() {
    return status == DEBOUT;
  }

  // -------- Passager : réactions du passager --------

  @Override
  public void accepterPlaceAssise() {
    status = ASSIS;
    message = ":accepterPlaceAssise:";
  }

  @Override
  public void accepterPlaceDebout() {
    status = DEBOUT;
    message = ":accepterPlaceDebout:";
  }

  @Override
  public void accepterSortie() {
    status = DEHORS;
    message = ":accepterSortie:";
  }

  @Override
  public void nouvelArret(Bus bus, int numeroArret) {
    message = ":nouvelArret " + numeroArret + ":";
  }
}
