package tec;

/**
 * Interface représentant l'état d'un passager dans un transport.
 * Un passager peut être :
 *  - dehors
 *  - assis
 *  - debout
 */
public interface IEtatPassager {

    /**
     * @return true si le passager est à l'extérieur du transport.
     */
    boolean estExterieur();

    /**
     * @return true si le passager est assis dans le transport.
     */
    boolean estAssis();

    /**
     * @return true si le passager est debout dans le transport.
     */
    boolean estDebout();

    /**
     * @return true si le passager est à l'intérieur (assis OU debout).
     */
    boolean estInterieur();
}

