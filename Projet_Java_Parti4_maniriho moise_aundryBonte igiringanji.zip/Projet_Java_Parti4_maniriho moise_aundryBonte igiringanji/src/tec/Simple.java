package tec;

/**
 * Petite simulation pour illustrer le fonctionnement du bus et des passagers.
 * À lancer avec : Run As -> Java Application.
 */
public class Simple {

    // On déclare que main peut relancer UsagerInvalideException
    public static void main(String[] args) throws UsagerInvalideException {
        // 1) Création du bus : 2 places assises, 2 debout
        Autobus bus = new Autobus(2, 2);

        // 2) Création de quelques passagers standards
        PassagerStandard p1 = new PassagerStandard("Kaylee", 2);
        PassagerStandard p2 = new PassagerStandard("Jayne", 3);
        PassagerStandard p3 = new PassagerStandard("Inara", 3);
        PassagerStandard p4 = new PassagerStandard("Zoe", 5);

        System.out.println("=== Début de la simulation ===");

        int arret = 0;
        afficherEtat(arret, p1, p2, p3, p4);

        // 3) Arrêt 0 : tout le monde essaie de monter
        System.out.println("\n--- Arrêt " + arret + " : montée des passagers ---");
        p1.monterDans(bus); // cherche d'abord une place assise
        p2.monterDans(bus); // cherche une place assise, sinon debout
        p3.monterDans(bus);
        p4.monterDans(bus); // si le bus est plein, elle reste dehors

        afficherEtat(arret, p1, p2, p3, p4);

        // 4) Le bus avance jusqu'à l'arrêt 5
        for (arret = 1; arret <= 5; arret++) {
            System.out.println("\n--- Arrêt " + arret + " ---");
            bus.allerArretSuivant();     // le bus annonce le nouvel arrêt
            afficherEtat(arret, p1, p2, p3, p4);
        }

        System.out.println("\n=== Fin de la simulation ===");
    }

    /**
     * Affiche l'état de chaque passager à un arrêt donné.
     */
    private static void afficherEtat(int arret, PassagerStandard... passagers) {
        System.out.println("État des passagers à l'arrêt " + arret + " :");
        for (PassagerStandard p : passagers) {
            String etat;
            if (p.estDehors()) {
                etat = "dehors";
            } else if (p.estAssis()) {
                etat = "assis";
            } else if (p.estDebout()) {
                etat = "debout";
            } else {
                etat = "inconnu";
            }
            System.out.println(" - " + p.nom() + " : " + etat);
        }
    }
}
