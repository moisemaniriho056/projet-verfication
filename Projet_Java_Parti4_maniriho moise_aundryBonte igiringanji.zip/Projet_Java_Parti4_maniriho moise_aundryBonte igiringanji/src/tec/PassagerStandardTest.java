package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class PassagerStandardTest {

    @Test
    public void nouvelUsagerEstDehors() {
        PassagerStandard p = new PassagerStandard("Kaylee", 5);
        assertTrue(p.estDehors());
    }

    @Test
    public void monterDansBusAvecPlaceAssiseLeMetAssis() throws UsagerInvalideException {
        Autobus bus = new Autobus(1, 0); // 1 assis, 0 debout
        PassagerStandard p = new PassagerStandard("Kaylee", 5);
        p.monterDans(bus);
        assertTrue(p.estAssis());
    }

    @Test
    public void monterDansBusAvecPlaceDeboutLeMetDebout() throws UsagerInvalideException {
        Autobus bus = new Autobus(0, 1); // 0 assis, 1 debout
        PassagerStandard p = new PassagerStandard("Jayne", 4);
        p.monterDans(bus);
        assertTrue(p.estDebout());
    }

    @Test
    public void monterDansBusPleinLeLaisseDehors() throws UsagerInvalideException {
        Autobus bus = new Autobus(0, 0); // aucune place
        PassagerStandard p = new PassagerStandard("Inara", 3);
        p.monterDans(bus);
        assertTrue(p.estDehors());
    }
}

