package tec;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Tests des exceptions levées par PassagerStandard.
 */
public class PassagerStandardExceptionTest {

    /**
     * Si on appelle monterDans() avec un Transport qui n'est pas un Bus,
     * on doit lever UsagerInvalideException (problème de conversion de type).
     */
    @Test
    public void monterDansTransportNonBusLanceUsagerInvalideException() {
        Usager u = new PassagerStandard("Beni", 5);
        Transport t = new FauxTransport();

        try {
            u.monterDans(t);
            fail("On aurait dû lever UsagerInvalideException quand le transport n'est pas un bus");
        } catch (UsagerInvalideException e) {
            // Si ta classe UsagerInvalideException possède ces accesseurs,
            // ces assertions vérifieront qu'on a bien les bons objets.
            // Sinon, tu peux commenter ces deux lignes.
            // assertSame(u, e.usager());
            // assertSame(t, e.transport());
        }
    }
}
