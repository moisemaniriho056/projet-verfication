package tec;

/**
 * Faux transport qui n'est pas un bus.
 * Sert uniquement pour les tests d'exception.
 */
public class FauxTransport implements Transport {

    @Override
    public void allerArretSuivant() {
        // Ne fait rien
    }
}
