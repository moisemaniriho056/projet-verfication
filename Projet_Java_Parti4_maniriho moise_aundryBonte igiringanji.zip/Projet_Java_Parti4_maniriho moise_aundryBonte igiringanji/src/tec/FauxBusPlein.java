package tec;

public class FauxBusPlein {
  String message = "???";

  boolean aPlaceAssise() {
    return false;
  }

  boolean aPlaceDebout() {
    return false;
  }

  void demanderPlaceAssise(Passager p) {
    message = ":demanderPlaceAssise:";
    // ne fait rien, bus plein
  }

  void demanderPlaceDebout(Passager p) {
    message = ":demanderPlaceDebout:";
    // ne fait rien, bus plein
  }
}
 