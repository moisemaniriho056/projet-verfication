package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class JaugeNaturelTest {

    // --- Tests sur l'état bleu / vert / rouge avec des valeurs VALABLES ---

    @Test
    public void estBleuQuandValeurZero() {
        JaugeNaturel j = new JaugeNaturel(5, 0);
        assertTrue(j.estBleu());
        assertFalse(j.estVert());
        assertFalse(j.estRouge());
    }

    @Test
    public void estVertQuandValeurEntreZeroEtMax() {
        JaugeNaturel j = new JaugeNaturel(5, 3);
        assertTrue(j.estVert());
        assertFalse(j.estBleu());
        assertFalse(j.estRouge());
    }

    // --- Tests sur les opérations incrementer / decrementer ---

    @Test
    public void incrementerFaitPasserDeBleuAVert() {
        JaugeNaturel j = new JaugeNaturel(5, 0);
        assertTrue(j.estBleu());

        j.incrementer();

        assertTrue(j.estVert());
        assertFalse(j.estBleu());
        assertFalse(j.estRouge());
    }

    @Test
    public void decrementerFaitPasserDeVertABleu() {
        JaugeNaturel j = new JaugeNaturel(5, 1);
        assertTrue(j.estVert());

        j.decrementer();

        assertTrue(j.estBleu());
        assertFalse(j.estVert());
        assertFalse(j.estRouge());
    }

    @Test
    public void incrementerPeutRendreRouge() {
        // valeur = max-1, encore verte
        JaugeNaturel j = new JaugeNaturel(5, 4);
        assertTrue(j.estVert());

        j.incrementer(); // valeur = 5

        assertTrue(j.estRouge());
        assertFalse(j.estVert());
        assertFalse(j.estBleu());
    }

    // --- Tests sur la création invalide (exceptions) ---

    /**
     * Vérifie que la création d'une jauge avec des paramètres invalides
     * lève bien IllegalArgumentException.
     */
    @Test
    public void creationNonValideLanceIllegalArgumentException() {
        // max <= 0
        try {
            new JaugeNaturel(0, 0);
            fail("On aurait dû lever IllegalArgumentException pour max <= 0");
        } catch (IllegalArgumentException e) {
            // OK : exception attendue
        }

        // valeur < 0
        try {
            new JaugeNaturel(5, -1);
            fail("On aurait dû lever IllegalArgumentException pour valeur < 0");
        } catch (IllegalArgumentException e) {
            // OK
        }

        // valeur >= max
        try {
            new JaugeNaturel(5, 5);
            fail("On aurait dû lever IllegalArgumentException pour valeur >= max");
        } catch (IllegalArgumentException e) {
            // OK
        }
    }
}
