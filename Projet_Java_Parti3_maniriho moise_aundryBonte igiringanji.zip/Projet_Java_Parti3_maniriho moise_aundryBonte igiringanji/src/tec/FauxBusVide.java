package tec;

public class FauxBusVide {
  String message = "???";

  boolean aPlaceAssise() {
    return true;
  }

  boolean aPlaceDebout() {
    return true;
  }

  void demanderPlaceAssise(Passager p) {
    message = ":demanderPlaceAssise:";
    p.accepterPlaceAssise();
  }

  void demanderPlaceDebout(Passager p) {
    message = ":demanderPlaceDebout:";
    p.accepterPlaceDebout();
  }

  void demanderChangerEnDebout(Passager p) {
    message = ":demanderChangerEnDebout:";
  }

  void demanderChangerEnAssis(Passager p) {
    message = ":demanderChangerEnAssis:";
  }

  void demanderSortie(Passager p) {
    message = ":demanderSortie:";    
    p.accepterSortie();
  }

  public void allerArretSuivant() {
    // rien, c'est un faux
  }
}
