package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class JaugeNaturelTest {

    // --- États de base ---

    @Test
    public void estBleuQuandValeurZero() {
        JaugeNaturel j = new JaugeNaturel(5, 0);
        assertTrue(j.estBleu());
    }

    @Test
    public void estBleuQuandValeurNegative() {
        JaugeNaturel j = new JaugeNaturel(5, -1);
        assertTrue(j.estBleu());
    }

    @Test
    public void estVertQuandValeurEntreZeroEtMax() {
        JaugeNaturel j = new JaugeNaturel(5, 3);
        assertTrue(j.estVert());
    }

    @Test
    public void estRougeQuandValeurEgaleMax() {
        JaugeNaturel j = new JaugeNaturel(5, 5);
        assertTrue(j.estRouge());
    }

    @Test
    public void estRougeQuandValeurSuperieureMax() {
        JaugeNaturel j = new JaugeNaturel(5, 8);
        assertTrue(j.estRouge());
    }

    // --- Comportement des méthodes ---

    @Test
    public void incrementerFaitPasserDeBleuAVert() {
        JaugeNaturel j = new JaugeNaturel(5, 0);
        j.incrementer();
        assertTrue(j.estVert());
    }

    @Test
    public void incrementerPeutRendreRouge() {
        JaugeNaturel j = new JaugeNaturel(2, 1); // [0..2[, 1 -> vert
        j.incrementer();                          // 2 -> rouge
        assertTrue(j.estRouge());
    }

    @Test
    public void decrementerFaitPasserDeVertABleu() {
        JaugeNaturel j = new JaugeNaturel(5, 1);
        j.decrementer();
        assertTrue(j.estBleu());
    }
}
