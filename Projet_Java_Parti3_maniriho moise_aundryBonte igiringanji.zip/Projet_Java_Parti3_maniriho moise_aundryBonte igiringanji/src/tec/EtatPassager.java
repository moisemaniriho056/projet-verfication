package tec;

/**
 * Cette classe représente l'état d'un passager dans un transport.
 *
 * Trois états possibles :
 *  - DEHORS
 *  - ASSIS
 *  - DEBOUT
 */
public class EtatPassager implements IEtatPassager {

    public enum Etat {
        ASSIS,
        DEBOUT,
        DEHORS
    }

    private final Etat monEtat;

    public EtatPassager(Etat e) {
        this.monEtat = e;
    }

    @Override
    public boolean estExterieur() {
        return monEtat == Etat.DEHORS;
    }

    @Override
    public boolean estAssis() {
        return monEtat == Etat.ASSIS;
    }

    @Override
    public boolean estDebout() {
        return monEtat == Etat.DEBOUT;
    }

    @Override
    public boolean estInterieur() {
        return monEtat == Etat.ASSIS || monEtat == Etat.DEBOUT;
    }

    @Override
    public String toString() {
        return "<" + monEtat + ">";
    }
}
