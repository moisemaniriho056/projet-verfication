package tec;

/**
 * Jauge sur les entiers naturels [0, max[.
 *
 * Une jauge peut être :
 * - BLEUE : valeur == 0
 * - VERTE : 0 < valeur < max
 * - ROUGE : valeur >= max
 */
class JaugeNaturel {

    /** Borne supérieure (non incluse). */
    private int max;

    /** Valeur courante de la jauge. */
    private int valeur;

    /**
     * Construit une jauge [0, max[ avec une valeur initiale.
     *
     * @param max    borne supérieure (strictement positive)
     * @param valeur valeur initiale
     */
    JaugeNaturel(int max, int valeur) {
        this.max = max;
        this.valeur = valeur;
    }

    /** @return vrai si la jauge est verte (0 < valeur < max). */
    boolean estVert() {
        return valeur > 0 && valeur < max;
    }

    /** @return vrai si la jauge est bleue (valeur <= 0). */
    boolean estBleu() {
        return valeur <= 0;
    }

    /** @return vrai si la jauge est rouge (valeur >= max). */
    boolean estRouge() {
        return valeur >= max;
    }

    /** Incrémente la valeur d'une unité, sans dépasser max. */
    void incrementer() {
        if (valeur < max) {
            valeur++;
        }
    }

    /** Décrémente la valeur d'une unité, sans descendre sous 0. */
    void decrementer() {
        if (valeur > 0) {
            valeur--;
        }
    }

    @Override
    public String toString() {
        return "<" + valeur + " [" + 0 + ".." + max + "]>";
    }
}
