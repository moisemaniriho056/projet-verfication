package tec;

/**
 * Implémentation standard d'un passager.
 * 
 * Il a :
 *  - un nom
 *  - un arrêt de destination
 *  - un état (dehors / assis / debout)
 */
public class PassagerStandard implements Usager, Passager {

    private final String nom;
    private final int destination;
    private EtatPassager etat;

    /**
     * Crée un passager à l'extérieur du bus.
     *
     * @param nom          nom du passager
     * @param destination  numéro de l'arrêt de destination
     */
    public PassagerStandard(String nom, int destination) {
        this.nom = nom;
        this.destination = destination;
        this.etat = new EtatPassager(EtatPassager.Etat.DEHORS);
    }

    // ===================== Usager =====================

    @Override
    public String nom() {
        return nom;
    }

    /**
     * Comportement à la montée : 
     *  - si place assise : demande une place assise
     *  - sinon si place debout : demande une place debout
     *  - sinon : reste dehors
     */
    @Override
    public void monterDans(Transport t) throws UsagerInvalideException {
        if (!(t instanceof Bus)) {
            // Transport qui n'est pas un bus : on ne gère pas
            throw new UsagerInvalideException("Transport non supporté", this, t);
        }

        Bus bus = (Bus) t;

        if (etat.estInterieur()) {
            // Il ne devrait pas être déjà dedans
            throw new UsagerInvalideException("Usager déjà dans un transport", this, t);
        }

        if (bus.aPlaceAssise()) {
            bus.demanderPlaceAssise(this);
        } else if (bus.aPlaceDebout()) {
            bus.demanderPlaceDebout(this);
        }
        // sinon : il reste dehors (rien à faire)
    }

    // ===================== Passager =====================

    @Override
    public boolean estDehors() {
        return etat.estExterieur();
    }

    @Override
    public boolean estAssis() {
        return etat.estAssis();
    }

    @Override
    public boolean estDebout() {
        return etat.estDebout();
    }

    @Override
    public void accepterSortie() {
        etat = new EtatPassager(EtatPassager.Etat.DEHORS);
    }

    @Override
    public void accepterPlaceAssise() {
        etat = new EtatPassager(EtatPassager.Etat.ASSIS);
    }

    @Override
    public void accepterPlaceDebout() {
        etat = new EtatPassager(EtatPassager.Etat.DEBOUT);
    }

    /**
     * À chaque arrêt, le bus appelle cette méthode.
     * Si on est arrivé à la destination → le passager demande à sortir.
     */
    @Override
    public void nouvelArret(Bus bus, int numeroArret) {
        if (numeroArret >= destination && etat.estInterieur()) {
            bus.demanderSortie(this);
        }
        // Sinon : ne fait rien dans cette version simple
    }

    @Override
    public String toString() {
        String etatStr;
        if (etat.estAssis()) {
            etatStr = "assis";
        } else if (etat.estDebout()) {
            etatStr = "debout";
        } else {
            etatStr = "dehors";
        }
        return nom + " " + etatStr;
    }
}

