package tec;

public class FauxBusAssis {
  String message = "???";

  boolean aPlaceAssise() {
    return true;
  }

  boolean aPlaceDebout() {
    return false;
  }

  void demanderPlaceAssise(Passager p) {
    message = ":demanderPlaceAssise:";
    p.accepterPlaceAssise();
  }

  void demanderPlaceDebout(Passager p) {
    message = ":demanderPlaceDebout:";
    // pas de place debout en réalité
  }
}
