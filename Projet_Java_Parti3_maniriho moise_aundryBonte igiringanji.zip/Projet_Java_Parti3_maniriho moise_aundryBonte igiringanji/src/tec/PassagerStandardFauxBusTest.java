package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class PassagerStandardFauxBusTest {

    // ---------- FauxBusVide ----------

    @Test
    public void accepterPlaceAssiseAvecFauxBus() {
        PassagerStandard p = new PassagerStandard("Beni", 5);
        assertTrue(p.estDehors());

        FauxBusVide bus = new FauxBusVide();
        bus.demanderPlaceAssise(p);

        assertTrue(p.estAssis());
        assertFalse(p.estDebout());
        assertFalse(p.estDehors());
        assertEquals(":demanderPlaceAssise:", bus.message);
    }

    @Test
    public void accepterPlaceDeboutAvecFauxBus() {
        PassagerStandard p = new PassagerStandard("Jayne", 4);
        FauxBusVide bus = new FauxBusVide();

        bus.demanderPlaceDebout(p);

        assertTrue(p.estDebout());
        assertFalse(p.estAssis());
        assertFalse(p.estDehors());
        assertEquals(":demanderPlaceDebout:", bus.message);
    }

    @Test
    public void sortirAvecFauxBus() {
        PassagerStandard p = new PassagerStandard("Zoe", 3);
        FauxBusVide bus = new FauxBusVide();

        // il monte assis
        bus.demanderPlaceAssise(p);
        assertTrue(p.estAssis());

        // puis il sort
        bus.demanderSortie(p);

        assertTrue(p.estDehors());
        assertEquals(":demanderSortie:", bus.message);
    }

    // ---------- FauxBusAssis ----------

    @Test
    public void fauxBusAssisDonneSeulementPlaceAssise() {
        // 1) demande de place assise
        PassagerStandard p1 = new PassagerStandard("Kaylee", 5);
        FauxBusAssis bus = new FauxBusAssis();

        bus.demanderPlaceAssise(p1);

        assertTrue(p1.estAssis());
        assertEquals(":demanderPlaceAssise:", bus.message);

        // 2) demande de place debout : pas de place debout
        PassagerStandard p2 = new PassagerStandard("Wash", 4);

        bus.demanderPlaceDebout(p2);

        assertTrue(p2.estDehors());
        assertEquals(":demanderPlaceDebout:", bus.message);
    }

    // ---------- FauxBusDebout ----------

    @Test
    public void fauxBusDeboutDonneSeulementPlaceDebout() {
        // 1) demande de place debout
        PassagerStandard p1 = new PassagerStandard("Zoe", 3);
        FauxBusDebout bus = new FauxBusDebout();

        bus.demanderPlaceDebout(p1);

        assertTrue(p1.estDebout());
        assertEquals(":demanderPlaceDebout:", bus.message);

        // 2) demande de place assise : pas de place assise
        PassagerStandard p2 = new PassagerStandard("Book", 6);

        bus.demanderPlaceAssise(p2);

        assertTrue(p2.estDehors());
        assertEquals(":demanderPlaceAssise:", bus.message);
    }

    // ---------- FauxBusPlein ----------

    @Test
    public void fauxBusPleinNeChangePasEtatPassager() {
        PassagerStandard p = new PassagerStandard("Inara", 2);
        FauxBusPlein bus = new FauxBusPlein();

        // demande de place assise
        bus.demanderPlaceAssise(p);
        assertTrue(p.estDehors());
        assertEquals(":demanderPlaceAssise:", bus.message);

        // demande de place debout
        bus.demanderPlaceDebout(p);
        assertTrue(p.estDehors());
        assertEquals(":demanderPlaceDebout:", bus.message);
    }
}
