package tec;

import java.util.ArrayList;
import java.util.List;

/**
 * Implémentation d'un autobus.
 *
 * Un autobus a :
 *  - un nombre max de places assises
 *  - un nombre max de places debout
 *  - une liste de passagers assis
 *  - une liste de passagers debout
 *  - un numéro d'arrêt courant
 */
public class Autobus implements Transport, Bus {

    private final int nbPlacesAssisesMax;
    private final int nbPlacesDeboutMax;

    private final List<Passager> assis;
    private final List<Passager> debout;

    private int numeroArret = 0;

    /**
     * Construit un autobus.
     *
     * @param nbPlacesAssises nombre maximum de places assises
     * @param nbPlacesDebout  nombre maximum de places debout
     */
    public Autobus(int nbPlacesAssises, int nbPlacesDebout) {
        this.nbPlacesAssisesMax = nbPlacesAssises;
        this.nbPlacesDeboutMax = nbPlacesDebout;
        this.assis = new ArrayList<>();
        this.debout = new ArrayList<>();
    }

    // ===================== Transport =====================

    /**
     * Passe à l'arrêt suivant et prévient tous les passagers.
     */
    @Override
    public void allerArretSuivant() throws UsagerInvalideException {
        numeroArret++;

        // On fait une copie pour éviter les problèmes si la liste change pendant l'itération
        List<Passager> tous = new ArrayList<>();
        tous.addAll(assis);
        tous.addAll(debout);

        for (Passager p : tous) {
            p.nouvelArret(this, numeroArret);
        }
    }

    // ===================== Bus =====================

    @Override
    public boolean aPlaceAssise() {
        return assis.size() < nbPlacesAssisesMax;
    }

    @Override
    public boolean aPlaceDebout() {
        return debout.size() < nbPlacesDeboutMax;
    }

    @Override
    public void demanderPlaceAssise(Passager p) {
        if (!p.estDehors()) {
            return; // Incohérent, on ignore dans cette version simple
        }
        if (aPlaceAssise()) {
            assis.add(p);
            p.accepterPlaceAssise();
        }
    }

    @Override
    public void demanderPlaceDebout(Passager p) {
        if (!p.estDehors()) {
            return;
        }
        if (aPlaceDebout()) {
            debout.add(p);
            p.accepterPlaceDebout();
        }
    }

    @Override
    public void demanderChangerEnDebout(Passager p) {
        if (!assis.contains(p) || !aPlaceDebout()) {
            return;
        }
        assis.remove(p);
        debout.add(p);
        p.accepterPlaceDebout();
    }

    @Override
    public void demanderChangerEnAssis(Passager p) {
        if (!debout.contains(p) || !aPlaceAssise()) {
            return;
        }
        debout.remove(p);
        assis.add(p);
        p.accepterPlaceAssise();
    }

    @Override
    public void demanderSortie(Passager p) {
        if (assis.remove(p) || debout.remove(p)) {
            p.accepterSortie();
        }
    }

    @Override
    public String toString() {
        return "[arret:" + numeroArret +
               ", assis:" + assis.size() +
               ", debout:" + debout.size() + "]";
    }
}

