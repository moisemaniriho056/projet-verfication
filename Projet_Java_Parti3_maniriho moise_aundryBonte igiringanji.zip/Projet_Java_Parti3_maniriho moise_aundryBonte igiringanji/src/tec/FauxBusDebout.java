package tec;

public class FauxBusDebout {
  String message = "???";

  boolean aPlaceAssise() {
    return false;
  }

  boolean aPlaceDebout() {
    return true;
  }

  void demanderPlaceDebout(Passager p) {
    message = ":demanderPlaceDebout:";
    p.accepterPlaceDebout();
  }

  void demanderPlaceAssise(Passager p) {
    message = ":demanderPlaceAssise:";
    // pas de place assise
  }
}
