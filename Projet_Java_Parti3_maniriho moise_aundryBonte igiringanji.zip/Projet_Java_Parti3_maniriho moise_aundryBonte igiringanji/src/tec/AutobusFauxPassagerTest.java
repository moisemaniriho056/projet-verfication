package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class AutobusFauxPassagerTest {

    @Test
    public void demanderPlaceAssiseAppelleAccepterPlaceAssise() {
        Autobus bus = new Autobus(2, 2);
        FauxPassager p = new FauxPassager();

        bus.demanderPlaceAssise(p);

        assertEquals(":accepterPlaceAssise:", p.message);
    }

    @Test
    public void demanderPlaceDeboutAppelleAccepterPlaceDebout() {
        Autobus bus = new Autobus(2, 2);
        FauxPassager p = new FauxPassager();

        bus.demanderPlaceDebout(p);

        assertEquals(":accepterPlaceDebout:", p.message);
    }

    @Test
    public void demanderSortieAppelleAccepterSortie() {
        Autobus bus = new Autobus(2, 2);

        FauxPassager p = new FauxPassager();
        bus.demanderPlaceAssise(p); // Il faut que le passager soit dans le bus
        p.message = "???"; // on réinitialise le message

        bus.demanderSortie(p);

        assertEquals(":accepterSortie:", p.message);
    }
}
