package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class UsagerTest {

    @Test
    public void nom_non_null() throws Exception {
        Usager u = new PassagerStandard("Alice", 3);
        assertEquals("Alice", u.nom());
    }

    @Test
    public void usager_est_dehors_au_depart() throws Exception {
        Usager u = new PassagerStandard("Bob", 2);

        assertTrue(u.estDehors());
        assertFalse(u.estAssis());
        assertFalse(u.estDebout());
    }

    @Test
    public void monter_dans_bus_vide_ne_plante_pas() throws Exception {
        Usager u = new PassagerStandard("Claire", 1);
        Transport bus = new FauxBusVide();

        u.monterDans(bus);
    }

    @Test
    public void nouvel_arret_ne_plante_pas() throws Exception {
        Usager u = new PassagerStandard("David", 2);
        Bus bus = new FauxBusVide();

        u.monterDans(bus);
        u.nouvelArret(bus, 1);
        u.nouvelArret(bus, 2);
    }

    @Test
    public void usager_descend_a_sa_destination() throws Exception {
        Usager u = new PassagerStandard("Emma", 2);
        Bus bus = new FauxBusVide();

        u.monterDans(bus);
        u.nouvelArret(bus, 1);

        // encore dans le bus
        assertFalse(u.estDehors());

        u.nouvelArret(bus, 2);

        // arrivé
        assertTrue(u.estDehors());
        assertFalse(u.estAssis());
        assertFalse(u.estDebout());
    }

    @Test(expected = UsagerInvalideException.class)
    public void destination_negative_interdite() throws Exception {
        new PassagerStandard("Erreur", -1);
    }
}
