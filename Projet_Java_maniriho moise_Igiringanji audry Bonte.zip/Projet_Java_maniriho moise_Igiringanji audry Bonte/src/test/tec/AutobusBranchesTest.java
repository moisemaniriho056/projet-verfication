package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class AutobusBranchesTest {

    @Test
    public void demander_place_assise_quand_aucune_place_assise_ne_change_pas_l_usager() throws Exception {
        // 0 assis, 1 debout
        Autobus bus = new Autobus(0, 1);
        Usager u = new PassagerStandard("A", 5);

        // Monter dans le bus => doit aller debout (car pas de place assise)
        u.monterDans(bus);

        assertFalse(u.estDehors());
        assertFalse(u.estAssis());
        assertTrue(u.estDebout());

        // Maintenant, même si on redemande assis, ça ne doit pas marcher (0 place assise)
        bus.demanderChangerEnAssis(u);
        assertFalse(u.estAssis());
        assertTrue(u.estDebout());
    }

    @Test
    public void demander_place_assise_quand_place_disponible_met_assis() throws Exception {
        Autobus bus = new Autobus(1, 0);
        Usager u = new PassagerStandard("B", 5);

        u.monterDans(bus);

        assertFalse(u.estDehors());
        assertTrue(u.estAssis());
        assertFalse(u.estDebout());
    }

    @Test
    public void demander_place_debout_quand_place_disponible_met_debout() throws Exception {
        Autobus bus = new Autobus(0, 1);
        Usager u = new PassagerStandard("C", 5);

        u.monterDans(bus);

        assertFalse(u.estDehors());
        assertFalse(u.estAssis());
        assertTrue(u.estDebout());
    }

    @Test
    public void demander_changer_en_debout_impossible_si_pas_de_place_debout() throws Exception {
        Autobus bus = new Autobus(1, 0);
        Usager u = new PassagerStandard("D", 5);

        u.monterDans(bus);
        assertTrue(u.estAssis());

        // Pas de place debout (0)
        bus.demanderChangerEnDebout(u);
        assertTrue(u.estAssis());
        assertFalse(u.estDebout());
    }

    @Test
    public void demander_changer_en_debout_possible_libere_une_place_assise() throws Exception {
        Autobus bus = new Autobus(1, 1);

        Usager u1 = new PassagerStandard("E1", 5);
        Usager u2 = new PassagerStandard("E2", 5);

        // u1 prend la place assise
        u1.monterDans(bus);
        assertTrue(u1.estAssis());

        // u2 prend la place debout
        u2.monterDans(bus);
        assertTrue(u2.estDebout());

        // u1 passe debout (il y a une place debout ? NON car déjà prise par u2)
        // Donc on libère d'abord: on fait sortir u2
        bus.demanderSortie(u2);
        assertTrue(u2.estDehors());

        // Maintenant u1 peut changer en debout
        bus.demanderChangerEnDebout(u1);
        assertTrue(u1.estDebout());
        assertFalse(u1.estAssis());

        // Comme u1 n'est plus assis, une place assise est de nouveau dispo.
        Usager u3 = new PassagerStandard("E3", 5);
        u3.monterDans(bus);
        assertTrue(u3.estAssis());
    }

    @Test
    public void demander_sortie_met_dehors_et_libere_une_place() throws Exception {
        Autobus bus = new Autobus(1, 0);
        Usager u1 = new PassagerStandard("F1", 5);
        Usager u2 = new PassagerStandard("F2", 5);

        u1.monterDans(bus);
        assertTrue(u1.estAssis());

        // Pas de place pour u2 => reste dehors
        u2.monterDans(bus);
        assertTrue(u2.estDehors());

        // u1 sort => libère la place
        bus.demanderSortie(u1);
        assertTrue(u1.estDehors());

        // u2 peut monter => assis
        u2.monterDans(bus);
        assertTrue(u2.estAssis());
    }

    @Test
    public void demander_place_assise_ignore_passager_non_usager() {
        Autobus bus = new Autobus(1, 1);

        Passager p = new Passager() {
            @Override public void accepterPlaceAssise() {}
            @Override public void accepterPlaceDebout() {}
            @Override public void accepterSortie() {}
        };

        // Ne doit pas planter, ni faire n'importe quoi
        bus.demanderPlaceAssise(p);
        bus.demanderPlaceDebout(p);
        bus.demanderChangerEnAssis(p);
        bus.demanderChangerEnDebout(p);
        bus.demanderSortie(p);
    }

    @Test
    public void demander_place_assise_sur_usager_deja_a_l_interieur_ne_doit_pas_dupliquer() throws Exception {
        Autobus bus = new Autobus(2, 0);
        Usager u = new PassagerStandard("G", 5);

        u.monterDans(bus);
        assertTrue(u.estAssis());

        // On essaye de "redemander" une place: ça ne doit pas créer d'incohérence.
        bus.demanderPlaceAssise(u);

        // Il est toujours juste assis, pas d'exception attendue ici.
        assertTrue(u.estAssis());
        assertFalse(u.estDebout());
        assertFalse(u.estDehors());
    }
}
