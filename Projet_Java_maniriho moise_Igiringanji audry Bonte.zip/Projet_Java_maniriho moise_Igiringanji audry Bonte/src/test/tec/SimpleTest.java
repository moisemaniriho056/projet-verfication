package tec;

import org.junit.Test;

public class SimpleTest {

  @Test
  public void main_ne_doit_pas_planter() throws Exception {
    Simple.main(new String[0]);
  }
}
