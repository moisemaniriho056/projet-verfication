package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class FauxBusPleinTest {

  @Test
  public void bus_plein_n_a_pas_de_place() {
    Bus bus = new FauxBusPlein();

    assertFalse(bus.aPlaceAssise());
    assertFalse(bus.aPlaceDebout());
  }

  @Test
  public void demandes_ne_plantent_pas() throws UsagerInvalideException {
    Bus bus = new FauxBusPlein();
    Passager p = new PassagerStandard("A", 1);

    bus.demanderPlaceAssise(p);
    bus.demanderPlaceDebout(p);
    bus.demanderChangerEnAssis(p);
    bus.demanderChangerEnDebout(p);
    bus.demanderSortie(p);
  }
}
