package tec;

import org.junit.Test;

public class PassagerStandardBranchesTest {

    @Test(expected = UsagerInvalideException.class)
    public void nom_null_interdit() throws Exception {
        new PassagerStandard(null, 1);
    }

    @Test(expected = UsagerInvalideException.class)
    public void nom_vide_interdit() throws Exception {
        new PassagerStandard("   ", 1);
    }

    @Test(expected = UsagerInvalideException.class)
    public void transport_null_interdit() throws Exception {
        Usager u = new PassagerStandard("A", 1);
        u.monterDans(null);
    }
}
