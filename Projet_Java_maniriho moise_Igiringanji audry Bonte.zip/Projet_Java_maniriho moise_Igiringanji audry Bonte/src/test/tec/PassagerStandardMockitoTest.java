package tec;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Test;

public class PassagerStandardMockitoTest {

    /**
     * Mock qui est à la fois Transport et Bus.
     * monterDans(Transport) marche, et on peut stub/verify côté Bus.
     */
    private static Transport mockTransportBus() {
        return mock(Transport.class, withSettings().extraInterfaces(Bus.class));
    }

    @Test
    public void monterDans_demandePlaceAssise_siDisponible() throws Exception {
        PassagerStandard p = new PassagerStandard("Kaylee", 2);

        Transport t = mockTransportBus();
        Bus bus = (Bus) t;

        when(bus.aPlaceAssise()).thenReturn(true);
        when(bus.aPlaceDebout()).thenReturn(true);

        doAnswer(invocation -> {
            Passager passager = invocation.getArgument(0);
            passager.accepterPlaceAssise();
            return null;
        }).when(bus).demanderPlaceAssise(any(Passager.class));

        p.monterDans(t);

        verify(bus, times(1)).demanderPlaceAssise(p);
        verify(bus, never()).demanderPlaceDebout(any(Passager.class));
        assertTrue(p.estAssis());
        assertFalse(p.estDehors());
        assertFalse(p.estDebout());
    }

    @Test
    public void monterDans_demandePlaceDebout_siAssisIndispo_et_DeboutDispo() throws Exception {
        PassagerStandard p = new PassagerStandard("Jayne", 3);

        Transport t = mockTransportBus();
        Bus bus = (Bus) t;

        when(bus.aPlaceAssise()).thenReturn(false);
        when(bus.aPlaceDebout()).thenReturn(true);

        doAnswer(invocation -> {
            Passager passager = invocation.getArgument(0);
            passager.accepterPlaceDebout();
            return null;
        }).when(bus).demanderPlaceDebout(any(Passager.class));

        p.monterDans(t);

        verify(bus, never()).demanderPlaceAssise(any(Passager.class));
        verify(bus, times(1)).demanderPlaceDebout(p);
        assertTrue(p.estDebout());
        assertFalse(p.estDehors());
        assertFalse(p.estAssis());
    }

    @Test
    public void monterDans_neDemandeRien_siAucunePlace() throws Exception {
        PassagerStandard p = new PassagerStandard("Inara", 4);

        Transport t = mockTransportBus();
        Bus bus = (Bus) t;

        when(bus.aPlaceAssise()).thenReturn(false);
        when(bus.aPlaceDebout()).thenReturn(false);

        p.monterDans(t);

        verify(bus, never()).demanderPlaceAssise(any(Passager.class));
        verify(bus, never()).demanderPlaceDebout(any(Passager.class));
        assertTrue(p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }

    @Test(expected = UsagerInvalideException.class)
    public void monterDans_exception_siTransportNonBus() throws Exception {
        PassagerStandard p = new PassagerStandard("Zoe", 5);
        Transport t = mock(Transport.class); // PAS un Bus
        p.monterDans(t);
    }
}
