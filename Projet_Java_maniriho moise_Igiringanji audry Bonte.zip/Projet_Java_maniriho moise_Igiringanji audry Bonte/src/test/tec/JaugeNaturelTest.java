package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class JaugeNaturelTest {

    @Test
    public void constructeur_initialiseValeurAZero_etMax() {
        JaugeNaturel j = new JaugeNaturel(3);

        assertEquals(0, j.valeur());
        assertEquals(3, j.max());
        assertTrue(j.estVide());
        assertFalse(j.estPlein());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructeur_refuseMaxNegatif() {
        new JaugeNaturel(-1);
    }

    @Test
    public void incrementer_augmenteValeur_jusquaMax() {
        JaugeNaturel j = new JaugeNaturel(2);

        j.incrementer();
        assertEquals(1, j.valeur());
        assertFalse(j.estVide());
        assertFalse(j.estPlein());

        j.incrementer();
        assertEquals(2, j.valeur());
        assertTrue(j.estPlein());
    }

    @Test(expected = IllegalStateException.class)
    public void incrementer_lanceException_siDejaPlein() {
        JaugeNaturel j = new JaugeNaturel(1);
        j.incrementer(); // valeur = 1 => plein
        assertTrue(j.estPlein());

        j.incrementer(); // doit throw
    }

    @Test
    public void decrementer_diminueValeur_jusquaZero() {
        JaugeNaturel j = new JaugeNaturel(3);

        j.incrementer();
        j.incrementer(); // valeur = 2
        assertEquals(2, j.valeur());

        j.decrementer();
        assertEquals(1, j.valeur());
        assertFalse(j.estVide());

        j.decrementer();
        assertEquals(0, j.valeur());
        assertTrue(j.estVide());
    }

    @Test(expected = IllegalStateException.class)
    public void decrementer_lanceException_siDejaVide() {
        JaugeNaturel j = new JaugeNaturel(3);
        assertTrue(j.estVide());

        j.decrementer(); // doit throw
    }

    @Test
    public void estPlein_et_estVide_sontCoherentsAuxBornes() {
        JaugeNaturel j = new JaugeNaturel(0);
        // max = 0 => plein dès le départ (valeur = 0)
        assertTrue(j.estPlein());
        assertTrue(j.estVide());
        assertEquals(0, j.valeur());
        assertEquals(0, j.max());
    }
}
