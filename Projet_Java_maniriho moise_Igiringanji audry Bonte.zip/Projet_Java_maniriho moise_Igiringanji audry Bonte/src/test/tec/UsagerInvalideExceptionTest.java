package tec;

import static org.junit.Assert.*;

import org.junit.Test;

public class UsagerInvalideExceptionTest {

    @Test
    public void constructeur_vide_message_null() {
        UsagerInvalideException e = new UsagerInvalideException();
        assertNull(e.getMessage());
        assertNull(e.getCause());
    }

    @Test
    public void constructeur_message_non_null() {
        UsagerInvalideException e = new UsagerInvalideException("message");
        assertEquals("message", e.getMessage());
        assertNull(e.getCause());
    }

    @Test
    public void constructeur_message_null_autorise() {
        UsagerInvalideException e = new UsagerInvalideException((String) null);
        assertNull(e.getMessage());
        assertNull(e.getCause());
    }

    @Test
    public void constructeur_cause_seule() {
        Throwable cause = new IllegalArgumentException("boom");
        UsagerInvalideException e = new UsagerInvalideException(cause);

        assertSame(cause, e.getCause());
        // Java met souvent le message = cause.toString() si on utilise super(cause)
        assertNotNull(e.getMessage());
    }

    @Test
    public void constructeur_message_et_cause() {
        Throwable cause = new RuntimeException("cause");
        UsagerInvalideException e = new UsagerInvalideException("msg", cause);

        assertEquals("msg", e.getMessage());
        assertSame(cause, e.getCause());
    }
}
