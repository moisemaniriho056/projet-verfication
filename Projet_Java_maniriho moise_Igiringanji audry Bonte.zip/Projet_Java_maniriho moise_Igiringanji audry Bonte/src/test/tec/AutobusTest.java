package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class AutobusTest {

    @Test
    public void initialement_busVide() throws Exception {
        Autobus bus = new Autobus(1, 1);
        assertTrue(bus.toString().contains("arret=0"));
        assertTrue(bus.toString().contains("passagers=0"));
    }

    @Test
    public void monterAssis_siPlaceAssise() throws Exception {
        Autobus bus = new Autobus(1, 0);
        PassagerStandard p = new PassagerStandard("A", 2);

        p.monterDans(bus);

        assertTrue(p.estAssis());
        assertFalse(p.estDehors());
        assertTrue(bus.toString().contains("passagers=1"));
    }

    @Test
    public void monterDebout_siPlusAssis_maisDeboutDispo() throws Exception {
        Autobus bus = new Autobus(0, 1);
        PassagerStandard p = new PassagerStandard("B", 2);

        p.monterDans(bus);

        assertTrue(p.estDebout());
        assertFalse(p.estDehors());
        assertTrue(bus.toString().contains("passagers=1"));
    }

    @Test
    public void monterRefuse_siBusPlein() throws Exception {
        Autobus bus = new Autobus(0, 0);
        PassagerStandard p = new PassagerStandard("C", 2);

        p.monterDans(bus);

        assertTrue(p.estDehors());
        assertTrue(bus.toString().contains("passagers=0"));
    }

    @Test
    public void changerPlace_assisVersDebout_siPossible() throws Exception {
        Autobus bus = new Autobus(1, 1);
        PassagerStandard p = new PassagerStandard("D", 5);

        p.monterDans(bus);
        assertTrue(p.estAssis());

        // demande de changement par le passager
        bus.demanderChangerEnDebout(p);

        assertTrue(p.estDebout());
        assertFalse(p.estAssis());
    }

    @Test
    public void demanderSortie_faitSortirEtDecremente() throws Exception {
        Autobus bus = new Autobus(1, 0);
        PassagerStandard p = new PassagerStandard("E", 1);

        p.monterDans(bus);
        assertTrue(bus.toString().contains("passagers=1"));

        bus.demanderSortie(p);

        assertTrue(p.estDehors());
        assertTrue(bus.toString().contains("passagers=0"));
    }

    @Test
    public void allerArretSuivant_declencheNouvelArret_etFaitDescendre() throws Exception {
        Autobus bus = new Autobus(1, 1);

        PassagerStandard p1 = new PassagerStandard("P1", 1);
        PassagerStandard p2 = new PassagerStandard("P2", 3);

        p1.monterDans(bus);
        p2.monterDans(bus);

        // arret 1 : p1 doit descendre
        bus.allerArretSuivant();
        assertTrue(p1.estDehors());
        assertFalse(p2.estDehors());

        // arret 2 : p2 reste
        bus.allerArretSuivant();
        assertFalse(p2.estDehors());

        // arret 3 : p2 descend
        bus.allerArretSuivant();
        assertTrue(p2.estDehors());
    }
}
