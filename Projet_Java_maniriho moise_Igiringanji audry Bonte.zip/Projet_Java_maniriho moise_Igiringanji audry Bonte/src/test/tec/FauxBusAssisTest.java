package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class FauxBusAssisTest {

    @Test
    public void a_place_assise_vrai_et_debout_faux() {
        Bus bus = new FauxBusAssis();
        assertTrue(bus.aPlaceAssise());
        assertFalse(bus.aPlaceDebout());
    }

    @Test
    public void toutes_les_demandes_ne_plantent_pas() throws Exception {
        Bus bus = new FauxBusAssis();
        Passager p = new PassagerStandard("A", 1);

        bus.demanderPlaceAssise(p);
        bus.demanderPlaceDebout(p);
        bus.demanderChangerEnAssis(p);
        bus.demanderChangerEnDebout(p);
        bus.demanderSortie(p);
    }

    @Test
    public void arret_et_aller_arret_suivant_ne_plantent_pas() throws Exception {
        Transport t = new FauxBusAssis();
        assertEquals(0, t.arret());
        t.allerArretSuivant();
        // si ton FauxBusAssis garde toujours 0, on ne vérifie pas la valeur,
        // on vérifie juste que ça s’exécute.
    }
}
