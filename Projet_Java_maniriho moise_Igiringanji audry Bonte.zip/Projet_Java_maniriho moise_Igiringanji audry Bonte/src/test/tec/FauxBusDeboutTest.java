package tec;

import static org.junit.Assert.*;
import org.junit.Test;

public class FauxBusDeboutTest {

  @Test
  public void bus_debout_a_place_debout_mais_pas_assise() {
    Bus bus = new FauxBusDebout();

    assertFalse(bus.aPlaceAssise());
    assertTrue(bus.aPlaceDebout());
  }

  @Test
  public void demandes_ne_plantent_pas() throws UsagerInvalideException {
    Bus bus = new FauxBusDebout();
    Passager p = new PassagerStandard("A", 1);

    bus.demanderPlaceAssise(p);
    bus.demanderPlaceDebout(p);
    bus.demanderChangerEnAssis(p);
    bus.demanderChangerEnDebout(p);
    bus.demanderSortie(p);
  }
}
