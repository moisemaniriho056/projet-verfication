package tec;

import static org.junit.Assert.*;

import org.junit.Test;

public class PassagerStandardTest {

    // ==========
    // Constructeur / état initial
    // ==========

    @Test
    public void constructeur_placeLePassagerDehors() throws Exception {
        PassagerStandard p = new PassagerStandard("Kaylee", 2);
        assertTrue(p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }

    @Test
    public void constructeurSecondaire_creeNomParDefaut() throws Exception {
        PassagerStandard p = new PassagerStandard(7);
        assertEquals("PassagerStandard7", p.nom());
        assertTrue(p.estDehors());
    }

    // Si ton code ne jette pas d'exception sur nom/destination invalides,
    // supprime ces 2 tests.
    @Test(expected = UsagerInvalideException.class)
    public void constructeur_leveException_siNomInvalide() throws Exception {
        new PassagerStandard("   ", 2);
    }

    @Test(expected = UsagerInvalideException.class)
    public void constructeur_leveException_siDestinationInvalide() throws Exception {
        new PassagerStandard("Zoe", -1);
    }

    // ==========
    // MonterDans avec FauxBus
    // ==========

    @Test
    public void monterDans_prendPlaceAssise_siBusVide() throws Exception {
        PassagerStandard p = new PassagerStandard("Kaylee", 2);
        FauxBusVide bus = new FauxBusVide();

        p.monterDans(bus);

        assertTrue("doit être assis", p.estAssis());
        assertFalse(p.estDebout());
        assertFalse(p.estDehors());
    }

    @Test
    public void monterDans_prendPlaceAssise_siAssisDisponible() throws Exception {
        PassagerStandard p = new PassagerStandard("Kaylee", 2);
        FauxBusAssis bus = new FauxBusAssis();

        p.monterDans(bus);

        assertTrue(p.estAssis());
        assertFalse(p.estDebout());
        assertFalse(p.estDehors());
    }

    @Test
    public void monterDans_prendPlaceDebout_siAssisIndispo_et_DeboutDispo() throws Exception {
        PassagerStandard p = new PassagerStandard("Jayne", 3);
        FauxBusDebout bus = new FauxBusDebout();

        p.monterDans(bus);

        assertTrue("doit être debout", p.estDebout());
        assertFalse(p.estAssis());
        assertFalse(p.estDehors());
    }

    @Test
    public void monterDans_resteDehors_siAucunePlace() throws Exception {
        PassagerStandard p = new PassagerStandard("Inara", 4);
        FauxBusPlein bus = new FauxBusPlein();

        p.monterDans(bus);

        assertTrue("doit rester dehors", p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }

    // ==========
    // nouvelArret
    // ==========

    @Test
    public void nouvelArret_sortALaDestination_siAssis() throws Exception {
        PassagerStandard p = new PassagerStandard("River", 2);
        FauxBusVide bus = new FauxBusVide();

        // le faire entrer
        p.monterDans(bus);
        assertTrue(p.estAssis() || p.estDebout());

        // arrivé à destination
        p.nouvelArret(bus, 2);

        assertTrue("doit être dehors après sortie", p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }

    @Test
    public void nouvelArret_sortALaDestination_siDebout() throws Exception {
        PassagerStandard p = new PassagerStandard("River", 2);
        FauxBusDebout bus = new FauxBusDebout();

        p.monterDans(bus);
        assertTrue(p.estDebout());

        p.nouvelArret(bus, 2);

        assertTrue(p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }

    @Test
    public void nouvelArret_neSortPas_siPasEncoreDestination() throws Exception {
        PassagerStandard p = new PassagerStandard("Simon", 5);
        FauxBusVide bus = new FauxBusVide();

        p.monterDans(bus);
        assertTrue(p.estAssis() || p.estDebout());

        p.nouvelArret(bus, 4);

        assertFalse("doit rester dans le bus", p.estDehors());
    }

    @Test
    public void nouvelArret_neFaitRien_siDehors() throws Exception {
        PassagerStandard p = new PassagerStandard("Book", 2);
        FauxBusVide bus = new FauxBusVide();

        assertTrue(p.estDehors());
        p.nouvelArret(bus, 10);

        assertTrue(p.estDehors());
    }

    // ==========
    // Méthodes d'état directes
    // ==========

    @Test
    public void accepterPlaceAssise_placeDebout_sortie_modifientEtat() throws Exception {
        PassagerStandard p = new PassagerStandard("Test", 1);

        assertTrue(p.estDehors());

        p.accepterPlaceAssise();
        assertTrue(p.estAssis());
        assertFalse(p.estDehors());
        assertFalse(p.estDebout());

        p.accepterPlaceDebout();
        assertTrue(p.estDebout());
        assertFalse(p.estDehors());
        assertFalse(p.estAssis());

        p.accepterSortie();
        assertTrue(p.estDehors());
        assertFalse(p.estAssis());
        assertFalse(p.estDebout());
    }
}
