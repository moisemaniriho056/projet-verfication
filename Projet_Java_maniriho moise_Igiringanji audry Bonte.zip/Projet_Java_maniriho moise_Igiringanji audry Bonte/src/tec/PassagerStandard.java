package tec;

public class PassagerStandard implements Usager {

    private final String nom;
    private final int destination;

    private boolean dehors = true;
    private boolean assis = false;
    private boolean debout = false;

    public PassagerStandard(String nom, int destination) throws UsagerInvalideException {
        if (nom == null || nom.isBlank()) {
            throw new UsagerInvalideException("Nom invalide");
        }
        if (destination < 0) {
            throw new UsagerInvalideException("Destination invalide");
        }
        this.nom = nom;
        this.destination = destination;
    }

    public PassagerStandard(int destination) throws UsagerInvalideException {
        this("PassagerStandard" + destination, destination);
    }

    // ----- Usager -----

    @Override
    public String nom() {
        return nom;
    }

    @Override
    public boolean estDehors() {
        return dehors;
    }

    @Override
    public boolean estAssis() {
        return assis;
    }

    @Override
    public boolean estDebout() {
        return debout;
    }

    private boolean estInterieur() {
        return assis || debout;
    }

    @Override
    public void monterDans(Transport t) throws UsagerInvalideException {
        if (t == null) {
            throw new UsagerInvalideException("Transport null");
        }
        if (!(t instanceof Bus)) {
            throw new UsagerInvalideException("Le transport n'est pas un bus");
        }
        if (estInterieur()) {
            throw new UsagerInvalideException("Passager déjà à l'intérieur");
        }

        Bus bus = (Bus) t;

        // Règle: si possible assis, sinon debout, sinon dehors
        if (bus.aPlaceAssise()) {
            bus.demanderPlaceAssise(this);
        } else if (bus.aPlaceDebout()) {
            bus.demanderPlaceDebout(this);
        }
        // sinon: aucune place -> il reste dehors (ne rien faire)
    }

    @Override
    public void nouvelArret(Bus bus, int numeroArret) throws UsagerInvalideException {
        if (bus == null) {
            throw new UsagerInvalideException("Bus null");
        }
        // si dehors, rien à faire
        if (!estInterieur()) {
            return;
        }
        // arrivé (ou dépassé) -> demande sortie
        if (numeroArret >= destination) {
            bus.demanderSortie(this);
        }
    }

    // ----- Passager -----

    @Override
    public void accepterPlaceAssise() {
        dehors = false;
        assis = true;
        debout = false;
    }

    @Override
    public void accepterPlaceDebout() {
        dehors = false;
        assis = false;
        debout = true;
    }

    @Override
    public void accepterSortie() {
        dehors = true;
        assis = false;
        debout = false;
    }

    @Override
    public String toString() {
        if (dehors) return nom + " (dehors)";
        if (assis) return nom + " (assis)";
        return nom + " (debout)";
    }
}
