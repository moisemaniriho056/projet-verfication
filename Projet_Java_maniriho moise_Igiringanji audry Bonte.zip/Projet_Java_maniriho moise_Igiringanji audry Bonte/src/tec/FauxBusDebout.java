package tec;

public class FauxBusDebout implements Bus {
    @Override public boolean aPlaceAssise() { return false; }
    @Override public boolean aPlaceDebout() { return true; }

    @Override public void demanderPlaceAssise(Passager p) { /* refuse */ }
    @Override public void demanderPlaceDebout(Passager p) { p.accepterPlaceDebout(); }
    @Override public void demanderChangerEnAssis(Passager p) { /* refuse */ }
    @Override public void demanderChangerEnDebout(Passager p) { p.accepterPlaceDebout(); }
    @Override public void demanderSortie(Passager p) { p.accepterSortie(); }

    @Override public int arret() { return 0; }
    @Override public void allerArretSuivant() throws UsagerInvalideException { /* rien */ }
}
