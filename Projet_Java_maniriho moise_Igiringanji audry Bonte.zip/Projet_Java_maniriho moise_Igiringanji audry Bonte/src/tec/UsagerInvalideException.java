package tec;

/**
 * Exception levée quand un usager (PassagerStandard, etc.)
 * est dans un état invalide ou reçoit des paramètres invalides
 * (ex: transport null, bus null, déjà à l'intérieur, etc.).
 */
public class UsagerInvalideException extends Exception {

    private static final long serialVersionUID = 1L;

    public UsagerInvalideException() {
        super();
    }

    public UsagerInvalideException(String message) {
        super(message);
    }

    public UsagerInvalideException(String message, Throwable cause) {
        super(message, cause);
    }

    public UsagerInvalideException(Throwable cause) {
        super(cause);
    }
}
