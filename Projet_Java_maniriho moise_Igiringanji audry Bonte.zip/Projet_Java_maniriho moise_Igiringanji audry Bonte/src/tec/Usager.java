package tec;

public interface Usager extends Passager {
    String nom();

    void monterDans(Transport t) throws UsagerInvalideException;

    void nouvelArret(Bus bus, int numeroArret) throws UsagerInvalideException;

    boolean estDehors();
    boolean estAssis();
    boolean estDebout();
}
