package tec;

import java.util.ArrayList;
import java.util.List;

public class Autobus implements Bus {

    private final JaugeNaturel assis;
    private final JaugeNaturel debout;

    private final List<Usager> passagers = new ArrayList<>();
    private int arretCourant = 0;

    public Autobus(int nbPlacesAssises, int nbPlacesDebout) {
        if (nbPlacesAssises < 0 || nbPlacesDebout < 0) {
            throw new IllegalArgumentException("capacités négatives");
        }
        this.assis = new JaugeNaturel(nbPlacesAssises);
        this.debout = new JaugeNaturel(nbPlacesDebout);
    }

    // ---- Transport ----

    @Override
    public int arret() {
        return arretCourant;
    }

    @Override
    public void allerArretSuivant() throws UsagerInvalideException {
        arretCourant++;

        // Copie pour éviter ConcurrentModificationException si un usager sort pendant la boucle
        List<Usager> copie = new ArrayList<>(passagers);
        for (Usager u : copie) {
            u.nouvelArret(this, arretCourant);
        }
    }

    // ---- Bus ----

    @Override
    public boolean aPlaceAssise() {
        return !assis.estPlein();
    }

    @Override
    public boolean aPlaceDebout() {
        return !debout.estPlein();
    }

    @Override
    public void demanderPlaceAssise(Passager p) {
        if (!(p instanceof Usager)) return;
        Usager u = (Usager) p;

        if (!aPlaceAssise()) return;

        // évite les doublons si jamais la méthode est appelée 2 fois
        if (!passagers.contains(u)) {
            passagers.add(u);
        }

        assis.incrementer();
        u.accepterPlaceAssise();
    }

    @Override
    public void demanderPlaceDebout(Passager p) {
        if (!(p instanceof Usager)) return;
        Usager u = (Usager) p;

        if (!aPlaceDebout()) return;

        if (!passagers.contains(u)) {
            passagers.add(u);
        }

        debout.incrementer();
        u.accepterPlaceDebout();
    }

    @Override
    public void demanderChangerEnDebout(Passager p) {
        if (!(p instanceof Usager)) return;
        Usager u = (Usager) p;

        if (u.estAssis() && aPlaceDebout()) {
            assis.decrementer();
            debout.incrementer();
            u.accepterPlaceDebout();
        }
    }

    @Override
    public void demanderChangerEnAssis(Passager p) {
        if (!(p instanceof Usager)) return;
        Usager u = (Usager) p;

        if (u.estDebout() && aPlaceAssise()) {
            debout.decrementer();
            assis.incrementer();
            u.accepterPlaceAssise();
        }
    }

    @Override
    public void demanderSortie(Passager p) {
        if (!(p instanceof Usager)) return;
        Usager u = (Usager) p;

        if (!passagers.remove(u)) return;

        // Important : décrémenter selon l'état AVANT accepterSortie()
        if (u.estAssis()) {
            assis.decrementer();
        } else if (u.estDebout()) {
            debout.decrementer();
        }

        u.accepterSortie();
    }

    @Override
    public String toString() {
        return "Autobus(arret=" + arretCourant
                + ", assis=" + assis.valeur() + "/" + assis.max()
                + ", debout=" + debout.valeur() + "/" + debout.max()
                + ", passagers=" + passagers.size() + ")";
    }
}
