package tec;

public class JaugeNaturel {
    private final int max;
    private int valeur;

    public JaugeNaturel(int max) {
        if (max < 0) throw new IllegalArgumentException("max < 0");
        this.max = max;
        this.valeur = 0;
    }

    public int valeur() {
        return valeur;
    }

    public int max() {
        return max;
    }

    public boolean estPlein() {
        return valeur >= max;
    }

    public boolean estVide() {
        return valeur <= 0;
    }

    public void incrementer() {
        if (estPlein()) throw new IllegalStateException("jauge pleine");
        valeur++;
    }

    public void decrementer() {
        if (estVide()) throw new IllegalStateException("jauge vide");
        valeur--;
    }
}
