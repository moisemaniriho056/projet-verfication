package tec;

public class FauxBusPlein implements Bus {
    @Override public boolean aPlaceAssise() { return false; }
    @Override public boolean aPlaceDebout() { return false; }

    @Override public void demanderPlaceAssise(Passager p) { /* refuse */ }
    @Override public void demanderPlaceDebout(Passager p) { /* refuse */ }
    @Override public void demanderChangerEnAssis(Passager p) { /* refuse */ }
    @Override public void demanderChangerEnDebout(Passager p) { /* refuse */ }
    @Override public void demanderSortie(Passager p) { p.accepterSortie(); }

    @Override public int arret() { return 0; }
    @Override public void allerArretSuivant() throws UsagerInvalideException { /* rien */ }
}
