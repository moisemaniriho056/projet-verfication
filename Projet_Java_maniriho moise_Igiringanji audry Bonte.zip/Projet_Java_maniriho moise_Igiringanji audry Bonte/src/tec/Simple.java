package tec;

public class Simple {

    public static void main(String[] args) throws UsagerInvalideException {

        // Création d’un bus : 1 place assise, 1 place debout
        Autobus bus = new Autobus(1, 1);

        // Création de passagers
        PassagerStandard p1 = new PassagerStandard("Kaylee", 2);
        PassagerStandard p2 = new PassagerStandard("Jayne", 3);

        // Les passagers montent
        p1.monterDans(bus);
        p2.monterDans(bus);

        System.out.println(bus);

        // Arrêt suivant
        bus.allerArretSuivant();
        System.out.println(bus);

        // Arrêt suivant
        bus.allerArretSuivant();
        System.out.println(bus);

        // Arrêt suivant
        bus.allerArretSuivant();
        System.out.println(bus);
    }
}
