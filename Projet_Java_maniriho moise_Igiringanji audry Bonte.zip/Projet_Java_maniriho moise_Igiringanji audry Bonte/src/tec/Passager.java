package tec;

public interface Passager {
    void accepterPlaceAssise();
    void accepterPlaceDebout();
    void accepterSortie();
}
