package tec;

public interface Transport {
    int arret();
    void allerArretSuivant() throws UsagerInvalideException;
}
